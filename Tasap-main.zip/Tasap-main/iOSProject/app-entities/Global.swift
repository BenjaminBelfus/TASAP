//
//  Global.swift
//  iOSProject
//
//  Created by Eduardo Huerta-Mercado on 4/12/20.
//  Copyright © 2020 Eduardo Huerta-Mercado. All rights reserved.
//

import Foundation

struct Global {
  
}
