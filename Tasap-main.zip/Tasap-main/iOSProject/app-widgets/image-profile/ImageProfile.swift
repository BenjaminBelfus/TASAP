//
//  ImageProfile.swift
//  iOSProject
//
//  Created by Eduardo Huerta-Mercado on 8/28/20.
//  Copyright © 2020 Eduardo Huerta-Mercado. All rights reserved.
//

import UIKit

class ImageProfile {
    
    
    static let shared = ImageProfile()
    
    init() {

    }
    
}
